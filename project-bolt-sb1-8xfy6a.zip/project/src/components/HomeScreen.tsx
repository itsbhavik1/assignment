import React, { useState } from 'react';
import { FormRenderer } from './FormRenderer';

const sampleXML = `
<?xml version="1.0" encoding="UTF-8"?>
<form>
  <fields>
    <field>
      <id>name</id>
      <type>text</type>
      <label>Full Name</label>
    </field>
    <field>
      <id>dob</id>
      <type>datetime</type>
      <label>Date of Birth</label>
    </field>
    <field>
      <id>gender</id>
      <type>radio</type>
      <label>Gender</label>
      <options>
        <option>Male</option>
        <option>Female</option>
        <option>Other</option>
      </options>
    </field>
    <field>
      <id>signature</id>
      <type>drawing</type>
      <label>Signature</label>
    </field>
  </fields>
</form>
`;

export function HomeScreen() {
  const [xmlInput, setXmlInput] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [currentXml, setCurrentXml] = useState('');

  const handlePredefinedForm = () => {
    setCurrentXml(sampleXML);
    setShowForm(true);
  };

  const handleCustomXml = () => {
    if (!xmlInput.trim()) {
      alert('Please enter XML input');
      return;
    }
    setCurrentXml(xmlInput);
    setShowForm(true);
  };

  return (
    <flexboxLayout className="flex-1">
      {!showForm ? (
        <stackLayout className="p-4 space-y-4">
          <button
            className="bg-blue-500 text-white p-4 rounded"
            onTap={handlePredefinedForm}
          >
            Render Form from XML File
          </button>
          
          <textView
            className="border p-2 rounded h-32"
            hint="Enter XML here..."
            text={xmlInput}
            onTextChange={(args) => setXmlInput(args.value)}
          />
          
          <button
            className="bg-green-500 text-white p-4 rounded"
            onTap={handleCustomXml}
          >
            Render Form from XML Input
          </button>
        </stackLayout>
      ) : (
        <stackLayout className="flex-1">
          <button
            className="bg-gray-500 text-white p-2"
            onTap={() => setShowForm(false)}
          >
            Back
          </button>
          <FormRenderer xmlContent={currentXml} />
        </stackLayout>
      )}
    </flexboxLayout>
  );
}