import React, { useState } from 'react';
import { parseString } from 'xml2js';
import { Alert, ScrollView, View } from '@nativescript/core';
import { TextField } from './form-fields/TextField';
import { DateTimeField } from './form-fields/DateTimeField';
import { RadioButtonGroup } from './form-fields/RadioButtonGroup';
import { DrawingField } from './form-fields/DrawingField';

interface FormRendererProps {
  xmlContent: string;
}

export const FormRenderer: React.FC<FormRendererProps> = ({ xmlContent }) => {
  const [formFields, setFormFields] = useState<any[]>([]);
  const [formData, setFormData] = useState({});

  React.useEffect(() => {
    parseXML(xmlContent);
  }, [xmlContent]);

  const parseXML = (xml: string) => {
    parseString(xml, (err, result) => {
      if (err) {
        Alert.alert('Error', 'Invalid XML format');
        return;
      }

      try {
        const fields = result.form.fields[0].field;
        setFormFields(fields);
      } catch (error) {
        Alert.alert('Error', 'Invalid form structure');
      }
    });
  };

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldId]: value
    }));
  };

  const renderField = (field: any) => {
    switch (field.type[0]) {
      case 'text':
        return (
          <TextField
            key={field.id[0]}
            id={field.id[0]}
            label={field.label[0]}
            value={formData[field.id[0]] || ''}
            onChange={(value) => handleFieldChange(field.id[0], value)}
          />
        );
      case 'datetime':
        return (
          <DateTimeField
            key={field.id[0]}
            id={field.id[0]}
            label={field.label[0]}
            value={formData[field.id[0]]}
            onChange={(value) => handleFieldChange(field.id[0], value)}
          />
        );
      case 'radio':
        return (
          <RadioButtonGroup
            key={field.id[0]}
            id={field.id[0]}
            label={field.label[0]}
            options={field.options[0].option}
            value={formData[field.id[0]]}
            onChange={(value) => handleFieldChange(field.id[0], value)}
          />
        );
      case 'drawing':
        return (
          <DrawingField
            key={field.id[0]}
            id={field.id[0]}
            label={field.label[0]}
            value={formData[field.id[0]]}
            onChange={(value) => handleFieldChange(field.id[0], value)}
          />
        );
      default:
        return null;
    }
  };

  return (
    <scrollView className="flex-1 p-4">
      <view className="space-y-4">
        {formFields.map(field => renderField(field))}
      </view>
    </scrollView>
  );
};