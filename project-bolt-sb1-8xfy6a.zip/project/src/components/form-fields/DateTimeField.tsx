import React from 'react';
import { DatePicker } from '@nativescript/core';

interface DateTimeFieldProps {
  id: string;
  label: string;
  value: Date;
  onChange: (value: Date) => void;
}

export const DateTimeField: React.FC<DateTimeFieldProps> = ({
  id,
  label: fieldLabel,
  value,
  onChange
}) => {
  return (
    <stackLayout className="mb-4">
      <label className="text-sm font-medium text-gray-700 mb-1">
        {fieldLabel}
      </label>
      <datePicker
        className="p-2 border rounded"
        date={value || new Date()}
        onDateChange={(args) => {
          const picker = args.object as DatePicker;
          onChange(picker.date);
        }}
      />
    </stackLayout>
  );
};