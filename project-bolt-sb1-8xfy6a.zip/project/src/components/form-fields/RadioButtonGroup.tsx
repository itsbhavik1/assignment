import React from 'react';
import { stackLayout } from '@nativescript/core';

interface RadioButtonGroupProps {
  id: string;
  label: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
}

export const RadioButtonGroup: React.FC<RadioButtonGroupProps> = ({
  id,
  label: fieldLabel,
  options,
  value,
  onChange
}) => {
  return (
    <stackLayout className="mb-4">
      <label className="text-sm font-medium text-gray-700 mb-1">
        {fieldLabel}
      </label>
      {options.map((option, index) => (
        <stackLayout
          key={`${id}-${index}`}
          className="flex-row items-center mb-2"
        >
          <button
            className={`w-5 h-5 rounded-full border-2 mr-2 ${
              value === option ? 'bg-blue-500' : 'bg-white'
            }`}
            onTap={() => onChange(option)}
          />
          <label className="text-sm">{option}</label>
        </stackLayout>
      ))}
    </stackLayout>
  );
};