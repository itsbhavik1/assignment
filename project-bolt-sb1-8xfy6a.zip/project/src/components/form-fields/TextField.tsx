import React from 'react';
import { textField, label } from '@nativescript/core';

interface TextFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
}

export const TextField: React.FC<TextFieldProps> = ({
  id,
  label: fieldLabel,
  value,
  onChange
}) => {
  return (
    <view className="mb-4">
      <label className="text-sm font-medium text-gray-700 mb-1">
        {fieldLabel}
      </label>
      <textField
        className="p-2 border rounded"
        text={value}
        onTextChange={(args) => onChange(args.value)}
      />
    </view>
  );
};