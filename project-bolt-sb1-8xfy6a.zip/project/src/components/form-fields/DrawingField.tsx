import React from 'react';
import { StackLayout, GridLayout } from '@nativescript/core';

interface DrawingFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
}

export const DrawingField: React.FC<DrawingFieldProps> = ({
  id,
  label: fieldLabel,
  value,
  onChange
}) => {
  return (
    <stackLayout className="mb-4">
      <label className="text-sm font-medium text-gray-700 mb-1">
        {fieldLabel}
      </label>
      <gridLayout
        className="border rounded-lg bg-white h-40"
        onPan={(args) => {
          // Basic drawing implementation using NativeScript's pan gesture
          const grid = args.object as GridLayout;
          const point = args.getLocationInView(grid);
          
          // Here you would implement the actual drawing logic
          // For now, we'll just notify that the drawing changed
          onChange(`Drawing updated at: ${point.x},${point.y}`);
        }}
      >
        <label text="Tap and drag to draw" className="text-center text-gray-500" />
      </gridLayout>
    </stackLayout>
  );
};